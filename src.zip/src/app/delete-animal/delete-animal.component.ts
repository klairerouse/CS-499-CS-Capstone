import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AnimalDataService } from '../services/animal-data.service';
import { Animal } from '../models/animal';

@Component({
  selector: 'app-delete-animal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './delete-animal.component.html',
  //styleUrl: './delete-animal.css',
})
export class DeleteAnimalComponent {
  animalCode: string ='';
  animal: any = null;
  message: string = '';

  constructor(private animalDataService: AnimalDataService) {}

  loadAnimal(): void {
    if (!this.animalCode) {
      this.message = 'Please enter an Animal ID';
      this.animal = null;
      return;
    }
    this.animalDataService.getAnimal(this.animalCode).subscribe({
      next: (value: any) => {
        if (!value || value.length === 0) {
          this.message = 'No Animal Found!';
          this.animal = null;
          return;
        }

          this.animal = value[0];
          this.message = 'Animal loaded successfully';
        },
        error: (error: any) => {
          console.log('Error:', error);
          this.message = 'Error retrieving animal';
          this.animal = null;
          }
      });
    }
    deleteAnimal(): void {
        if (!this.animalCode) {
          this.message = 'Please enter an Animal ID';
          return;
        }

        if (!confirm(`Are you sure you want to delete animal ${this.animalCode}?`)) {
          return;
        }

        this.animalDataService.deleteAnimal(this.animalCode).subscribe({
          next: (value: any) => {
            console.log(value);
            window.location.href = 'http://localhost:3000/aac';
          },
          error: (error: any) => {
            console.log('Error:', error);
            this.message = 'Error deleting animal';
          }
        });
      }
    }