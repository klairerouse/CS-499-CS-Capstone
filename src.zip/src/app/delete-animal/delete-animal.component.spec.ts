import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteAnimalComponent } from './delete-animal.component';

describe('DeleteAnimal', () => {
  let component: DeleteAnimalComponent;
  let fixture: ComponentFixture<DeleteAnimalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DeleteAnimalComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(DeleteAnimalComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
