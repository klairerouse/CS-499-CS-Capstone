import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { aac_animals } from '../data/aac_animals';
import { AnimalCard } from '../animal-card/animal-card.component';

@Component({
  selector: 'app-animal-listing',
  standalone: true, 
  imports: [CommonModule, AnimalCard],
  templateUrl: './animal-listing.component.html',
  styleUrl: './animal-listing.component.css'
})

export class AnimalListing implements OnInit {
  aac_animals: Array<any> = aac_animals;

  constructor() {}

  ngOnInit(): void{
    
  }

}
