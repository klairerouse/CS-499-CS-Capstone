import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from "@angular/forms";
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';
import { User } from '../models/user';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule ],
  templateUrl: './login.component.html'
})

export class LoginComponent implements OnInit {
  public formError: string = '';
  public returnUrl = 'http://localhost:3000/aac';
    submitted = false;
    credentials = {
      name: '',
      email: '',
      password: ''
  }

  constructor(
    private route: ActivatedRoute,
    private authenticationService: AuthenticationService
  ) { }

  ngOnInit(): void {
     const queryReturnUrl = this.route.snapshot.queryParamMap.get('returnUrl');
     this.returnUrl = this.route.snapshot.queryParamMap.get('returnUrl') || 'http://localhost:3000/aac';
     console.log('returnUrl =', this.returnUrl);
    }

  public onLoginSubmit(): void {
    this.formError = '';
    if (!this.credentials.email || !this.credentials.password) {
      this.formError = 'All fields are required, please try again';
      return;
      
    } 
      this.doLogin();
    
  }

 private doLogin(): void {
    let newUser = {
      name: this.credentials.name,
      email: this.credentials.email
    } as User;
  
    // console.log('LoginComponent::doLogin');
    // console.log(this.credentials);
    
this.authenticationService.login(newUser, this.credentials.password).subscribe({
      next: () => {
        document.cookie = "animalLoggedIn=true; path=/";
        console.log('Login successful, redirecting to:', this.returnUrl);
       // window.location.assign(this.returnUrl);
       window.location.href = 'http://localhost:3000/aac';
        //this.router.navigateByUrl(this.returnUrl);
      },
      error: (err) => {
        console.error('Login failed:', err);
        this.formError = err?.error?.message || 'Login failed.';
        //this.formError = err?.error?.message || 'Login failed.';
      }
    });
  }
}



