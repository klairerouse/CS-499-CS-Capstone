import { Inject, Injectable } from '@angular/core';
import { BROWSER_STORAGE } from '../storage';
import { User } from '../models/user';
import { AuthResponse } from '../models/auth-response';
import { AnimalDataService } from '../services/animal-data.service';
import { Observable, tap } from 'rxjs';

@Injectable({
  providedIn: 'root',
})

export class AuthenticationService {
  constructor(
    @Inject(BROWSER_STORAGE) private storage: Storage,
    private animalDataService: AnimalDataService
  ) {}

  public getToken(): string | null {
    return localStorage.getItem('animal-token') || '';
  }

  public saveToken(token: string): void {
     localStorage.setItem('animal-token', token);
  }

  public logout(): void {
    localStorage.removeItem('animal-token');
  }

  public isLoggedIn(): boolean {
    const token = this.getToken();
    if (token) {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.exp > (Date.now() / 1000);
    }
    return false;
  }

  public getCurrentUser(): User {
    const token = this.getToken();

    if (!token) {
      return {email: '', name: ''} as User;
    }

    const { email, name } = JSON.parse(atob(token.split('.')[1]));
    return { email, name } as User;
  }

  public login(user: User, passwd: string): Observable<AuthResponse> {
    return this.animalDataService.login(user, passwd).pipe(
      tap((value: AuthResponse) => {
        this.saveToken(value.token);
      })
    );
  }

  public register(user: User, passwd: string): Observable<AuthResponse> {
    return this.animalDataService.register(user, passwd).pipe(
      tap((value: AuthResponse) => {
        this.saveToken(value.token);
      })
    );
  }
}

