
import { Routes } from "@angular/router";
import { LoginComponent } from "./login/login.component";
import { AnimalListing } from "./animal-listing/animal-listing.component";
import { AddAnimalComponent } from './add-animal/add-animal.component';
import { EditAnimalComponent } from './edit-animal/edit-animal.component';
import { DeleteAnimalComponent } from './delete-animal/delete-animal.component';
import { authGuard } from './utils/auth.guard';

export const routes: Routes = [
    { path: 'add-animal', component: AddAnimalComponent, canActivate: [authGuard] },
    { path: 'edit-animal', component: EditAnimalComponent, canActivate: [authGuard] },
    { path: 'delete-animal', component: DeleteAnimalComponent },
    {path: 'login', component: LoginComponent},
    {path: '', component: AnimalListing, pathMatch: 'full'},
    {path: '**', redirectTo: ''}
];

