import { CommonModule } from '@angular/common';
import { Component, OnInit, Input } from '@angular/core';
import { aac_animals } from '../data/aac_animals';

@Component({
  selector: 'app-animal-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './animal-card.component.html'
})
export class AnimalCard implements OnInit {

  @Input('animal') animal: any;

  constructor() {}

  ngOnInit(): void {
    
  }
}
