					
export const aac_animals = [
    {
        "Age_Upon_Outcome" : "5 years",
        "Animal_ID" : "A696004",
        "Animal_Type" : "Dog",
        "Breed" : "Cardigan Welsh Corgi Mix",
        "Color" : "Sable/White",
        "Date_of_Birth" : "1/27/2010",
        "Datetime" : "1/28/2025 10:39 AM",
        "Monthyear" : "2015-01-28T10:39:00",
        "Name" : "Lucy",
        "Outcome_Subtype" : "Rabies Risk",
        "Outcome_Type" : "Euthanasia",
        "Sex_Upon_Outcome" : "Spayed Female",
        "Location_Lat" : "30.6737365854231",
        "Location_Long" : "-97.707971529467",
        "Age_Upon_Outcome_in_weeks" : "261.063392857143"
    },
        {
        "Age_Upon_Outcome" : "1 year",
        "Animal_ID" : "A681101",
        "Animal_Type" : "Cat",
        "Breed" : "Domestic Shorthair Mix",
        "Color" : "Brown Tabby",
        "Date_of_Birth" : "6/12/2013",
        "Datetime" : "6/19/2014  2:36:00 PM",
        "Monthyear" : "2014-06-19T14:36:00",
        "Name" : "Spaghetti",
        "Outcome_Subtype" : "Partner",
        "Outcome_Type" : "Transfer",
        "Sex_Upon_Outcome" : "Spayed Female",
        "Location_Lat" : "30.5917805179688",
        "Location_Long" : "-97.7321173379875",
        "Age_Upon_Outcome_in_weeks" : "53.2297619047619"

    },
        {
        "Age_Upon_Outcome" : "6 months",
        "Animal_ID" : "A751514",
        "Animal_Type" : "Bird",
        "Breed" : "Chicken Mix",
        "Color" : "Red",
        "Date_of_Birth" : "12/9/2016",
        "Datetime" : "6/10/2017  10:42:00 AM",
        "Monthyear" : "2017-06-10T10:42:00",
        "Name" : "Starlight",
        "Outcome_Subtype" : "Offsite",
        "Outcome_Type" : "Adoption",
        "Sex_Upon_Outcome" : "Unknown",
        "Location_Lat" : "30.7394213569125",
        "Location_Long" : "-97.7205841386353",
        "Age_Upon_Outcome_in_weeks" : "26.2065476190476"

    }
];