import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule
} from '@angular/forms';

import { Router } from '@angular/router';
import {AnimalDataService} from '../services/animal-data.service';

@Component({
  selector: 'app-add-animal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './add-animal.component.html'

})

export class AddAnimalComponent implements OnInit {
  public addForm!: FormGroup;
  submitted = false;
  formError ='';

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private animalService: AnimalDataService
  ){}

  ngOnInit(): void {
    this.addForm = this.formBuilder.group({
      animal_id: ['', Validators.required],
      age_upon_outcome: ['', Validators.required],
      animal_type: ['', Validators.required],
      breed: ['', Validators.required],
      color: ['', Validators.required],
      date_of_birth: ['', Validators.required],
      datetime: ['', Validators.required],
      monthyear: ['', Validators.required],
      name: ['', Validators.required],
      outcome_subtype: ['', Validators.required],
      outcome_type: ['', Validators.required],
      sex_upon_outcome: ['', Validators.required],
      location_lat: ['', Validators.required],
      location_long: ['', Validators.required],
      age_upon_outcome_in_weeks: ['', Validators.required]
    });
  }
  
 public onSubmit(): void {
    this.submitted = true;
    this.formError = '';

    if (this.addForm.invalid) {
      return;
    }

    const formValue = this.addForm.value;

    const newAnimal = {
      ...formValue,
      location_lat: Number(formValue.location_lat),
      location_long: Number(formValue.location_long),
      age_upon_outcome_in_weeks:
        formValue.age_upon_outcome_in_weeks !== ''
          ? Number(formValue.age_upon_outcome_in_weeks)
          : null
    };

    this.animalService.addAnimal(newAnimal).subscribe({
      next: () => {
        window.location.href = 'http://localhost:3000/aac';
      },
      error: (err) => {
        this.formError = err?.error?.message || 'Unable to save animal record.';
      }
    });
  }

  get f() {
    return this.addForm.controls;
  }
}
