import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
  FormsModule
} from '@angular/forms';
import { AnimalDataService } from '../services/animal-data.service';
//import { Animal } from '../models/animal'; --never used

@Component({
  selector: 'app-edit-animal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './edit-animal.component.html',
  styleUrl: './edit-animal.component.css',
})

export class EditAnimalComponent implements OnInit {
  public editForm!: FormGroup;
  trip!: any;
  submitted = false;
  message: string = '';

  animalCode: string = '';

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private animalDataService: AnimalDataService
  ) {}

  loadAnimal(): void {
  if (!this.animalCode) {
    this.message = 'Please enter an Animal ID';
    return;
  }

  console.log('Loading animal:', this.animalCode);

  this.animalDataService.getAnimal(this.animalCode).subscribe({
    next: (value: any) => {
      if (!value || value.length === 0) {
        this.message = 'No Animal Found!';
        return;
      }

      this.editForm.patchValue(value[0]);
      this.message = 'Animal loaded successfully';
    },
    error: (error: any) => {
      console.log('Error:', error);
      this.message = 'Error retrieving animal';
    }
  });
}

  ngOnInit(): void {
         
      console.log('EditAnimalComponent::ngOnInit');
      //console.log('animalCode: ' + animalCode);

      //initialize form
      this.editForm = this.formBuilder.group({
        animal_id: [],
        age_upon_outcome: ['', Validators.required],
        animal_type: ['', Validators.required],
        breed: ['', Validators.required],
        color: ['', Validators.required],
        date_of_birth: ['', Validators.required],
        datetime: ['', Validators.required],
        monthyear: ['', Validators.required],
        name: ['', Validators.required],
        outcome_subtype: ['', Validators.required],
        outcome_type: ['', Validators.required],
        sex_upon_outcome: ['', Validators.required],
        location_lat: ['', Validators.required],
        location_long: ['', Validators.required],
        age_upon_outcome_in_weeks: ['', Validators.required]
      });

      }
      
      public onSubmit(): void {
        this.submitted = true;
        if (this.editForm.valid)  {
          this.animalDataService.updateAnimal(this.editForm.value).subscribe({
            next: (value: any) => {
              console.log(value);
              //this.router.navigate(['']);
              window.location.href = 'http://localhost:3000/aac';
            },
          });
        }
      }

      //get the form short name to access the form fields
      get f() {
        return this.editForm.controls;
      }
    }
