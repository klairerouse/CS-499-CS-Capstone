export interface Animal {
    _id: string,
    animal_id: string,
    age_upon_outcome: string,
    animal_type: string,
    breed: string,
    color: string,
    date_of_birth: Date,
    datetime: Date,
    monthyear: Date,
    name: string,
    outcome_subtype: string,
    outcome_type: string,
    sex_upon_outcome: string,
    location_lat: number,
    location_long: number,
    age_upon_outcome_in_weeks: number
}